// Jerry Vasquez
// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
// #include "gtest/gtest.h"
#include <vector>
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// TODO: Create a test to verify adding a single value to an empty collection
// DONE
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty? ASSERT: if collection was not empty (which is the whole point of this test) then the test should terminate
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);
    
    // add an element
    add_entries(1);

    // collection must not be empty anymore
    EXPECT_FALSE(collection->empty());
    // size must be 1
    EXPECT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
// DONE
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // starting collection size
    size_t start_size = collection->size();
    // add 5
    add_entries(5);
    // size should be 5 more
    EXPECT_EQ(collection->size(), start_size + 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
// DONE
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize) {
    const std::vector<int> sizes = { 0, 1, 5, 10 };

    // iterate through sizes and test for each size
    for (int size : sizes) {
        if (size > 0) { 
            // each iter add new entries such that collection->size() equals size
            add_entries(size - collection->size()); 
        }
        // test 
        EXPECT_GE(collection->max_size(), collection->size());
    }
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
// DONE
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize) {
    const std::vector<int> sizes = { 0, 1, 5, 10 };

    // iterate through sizes and test for each size
    for (int size : sizes) {
        if (size > 0) {
            // each iter add new entries such that collection->size() equals size
            add_entries(size - collection->size());
        }
        // test capacity >= size
        EXPECT_GE(collection->capacity(), collection->size());
    }
}

// TODO: Create a test to verify resizing increases the collection
// DONE
TEST_F(CollectionTest, ResizingIncreasesCollectionSize) {
    // add a element
    add_entries(1);
    // get starting size
    size_t starting_size = collection->size();

    // resize by 1
    collection->resize(starting_size + 1);

    // test 
    EXPECT_EQ(collection->size(), starting_size + 1);
}

// TODO: Create a test to verify resizing decreases the collection
// DONE
TEST_F(CollectionTest, ResizingDecreasesCollectionSize) {
    // add 2 elements
    add_entries(2);
    // get starting size 
    size_t starting_size = collection->size();
    // resize to lower size
    collection->resize(1);
    // check 
    EXPECT_EQ(collection->size(), starting_size-1);
}

// TODO: Create a test to verify resizing decreases the collection to zero
// DONE
TEST_F(CollectionTest, ResizeToZeroMakesCollectionEmpty) {
    // add an element
    add_entries(1);
    // resize to 0
    collection->resize(0);

    // size must be 0 and collection must be empty
    EXPECT_EQ(collection->size(), 0);
    EXPECT_TRUE(collection->empty());
}

// TODO: Create a test to verify clear erases the collection
// DONE
TEST_F(CollectionTest, ClearErasesTheCollection) {
    // fill the collection then use clear()
    add_entries(1);
    collection->clear();

    // collection size must be 0 and empty() must be true
    EXPECT_EQ(collection->size(), 0);
    EXPECT_TRUE(collection->empty());
}

// TODO: Create a test to verify erase(begin,end) erases the collection
// DONE
TEST_F(CollectionTest, EraseBeginToEndRemovesAllElements) {
    // fill the collection
    add_entries(5);
    // erase from begin() to end()
    collection->erase(collection->begin(), collection->end());

    // collection must be 0 and empty() must be true
    EXPECT_EQ(collection->size(), 0);
    EXPECT_TRUE(collection->empty());
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
// DONE
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize) {
    // collection starts empty
    size_t starting_capacity = collection->capacity(); // 0
    size_t starting_size = collection->size(); // 0

    // reserve 10
    collection->reserve(starting_capacity + 10);

    // capacity must have increased to at least 10 and size must be the same
    EXPECT_GE(collection->capacity(), starting_capacity + 10);
    EXPECT_EQ(collection->size(), starting_size);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
// DONE
TEST_F(CollectionTest, AtThrowsOutOfRangeException) {
    // add 5 elements
    add_entries(5); 

    // size always 1 more than the last index. 
    int out_of_range_index = collection->size();

    // Attempting to access out_of_range_index should throw out_of_range exception
    EXPECT_THROW(collection->at(out_of_range_index), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// positive test: Verify pop back reduces size by 1
TEST_F(CollectionTest, PopBackDecreasesSizeByOne) {
    // add an item
    add_entries(1);
    // get starting size
    size_t starting_size = collection->size();

    // pop_back
    collection->pop_back();

    // size must be 1 less starting size
    EXPECT_EQ(collection->size(), starting_size - 1);
}

// negative test: reserve more than max size throws length error eception
TEST_F(CollectionTest, ReservePastMaxSizeThrowsLengthErrorEception) {
    // get max size
    size_t max_size = collection->max_size();

    // test
    EXPECT_THROW(collection->reserve(max_size + 1), std::length_error);
}